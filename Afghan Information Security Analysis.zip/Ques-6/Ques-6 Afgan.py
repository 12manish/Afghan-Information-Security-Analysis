#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt                  # Importing required libraries
get_ipython().run_line_magic('matplotlib', 'inline')
import os
import sklearn
import warnings
warnings.filterwarnings("ignore")


# #### Importing Dataset

# In[3]:


os.chdir("C:/Users/ABC/Desktop/Afgan Forum paper in R/afghanForum")
data=pd.read_csv("afghanForum.csv",error_bad_lines=False)
data.head()


# In[4]:


dat=data[["MessageID","Message"]]
dat.shape


# #### Sentiment analysis of message column in data

# In[5]:


from textblob import TextBlob
import re
import textblob


# In[6]:


def clean_text(text): 
        ''' 
        Utility function to clean text by removing links,
        special characters using simple regex statements. 
        '''
        return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)", " ", text).split()) 

def get_text_sentiment(text):
    ''' 
    Utility function to classify sentiment of passed
    text using textblob's sentiment method 
    '''
    # create TextBlob object of passed text 
    analysis = TextBlob(clean_text(text)) 
    # set sentiment 
    if analysis.sentiment.polarity > 0: 
        return 'positive'
    elif analysis.sentiment.polarity == 0: 
        return 'neutral'
    else: 
        return 'negative'    


# In[7]:


sentiment = []
for message in dat['Message']:
    sentiment.append(get_text_sentiment(message))
    
dat["Sentiment"] = sentiment
dat.head()


# In[8]:


dat['Sentiment_Score'] = dat.Sentiment.map({'positive':1, 'negative':-1,'neutral':0})


# In[9]:


dat.head()


# #### Converting text in Message column to lower case

# In[10]:


dat['Message'] = [entry.lower() for entry in dat['Message']]
dat.head()


# #### Removing punctuation and doing word tokenization of text data

# In[11]:


from nltk.tokenize import RegexpTokenizer
tokenizer = RegexpTokenizer(r'\w+')
dat['Message']= [tokenizer.tokenize(entry) for entry in dat['Message']]


# In[12]:


dat['Message']=[" ".join(content) for content in dat['Message'].values]


# #### Removing stop words

# In[13]:


from nltk.corpus import stopwords
stop = stopwords.words('english')


# In[14]:


dat['Message']=dat['Message'].apply(lambda x: " ".join(x for x in x.split() if x not in stop))


# In[15]:


dat.head()


# #### Model Building

# In[16]:


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn import model_selection, naive_bayes, svm
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report


# In[17]:


Y=dat["Sentiment_Score"]


# #### Splitting data in train and test in 70:30

# In[18]:


Train_X, Test_X, Train_Y, Test_Y = model_selection.train_test_split(dat['Message'],Y,test_size=0.3)


# In[19]:


print(Train_X.shape,Test_X.shape,Train_Y.shape,Test_Y.shape)


# #### TFIDF Vectorizer of train and test data

# In[20]:


Tfidf_vect = TfidfVectorizer(stop_words='english')
Train_X_Tfidf = Tfidf_vect.fit_transform(Train_X)
Test_X_Tfidf = Tfidf_vect.transform(Test_X)


# #### Count vectorizer of train and test data

# In[21]:


from sklearn.feature_extraction.text import CountVectorizer
count_vectorizer = CountVectorizer(stop_words='english')

# Fit and transform the training data 
count_train = count_vectorizer.fit_transform(Train_X) 

# Transform the test set 
count_test = count_vectorizer.transform(Test_X)


# In[22]:


print(Train_X_Tfidf.shape,Test_X_Tfidf.shape,count_train.shape,count_test.shape)


# #### Random forest classifier on count vectorizer data

# In[23]:


from sklearn.ensemble import RandomForestClassifier
rf= RandomForestClassifier(n_estimators=100, max_depth=2,random_state=0)
rf.fit(count_train,Train_Y)
predictions_rf = rf.predict(count_test)

print("Random Forest Accuracy Score -> ",accuracy_score(predictions_rf, Test_Y)*100)


# In[24]:


confusion_matrix(Test_Y, predictions_rf)


# #### Random forest classifier on TFIDF vectorizer data

# In[27]:


rf1= RandomForestClassifier(n_estimators=100, max_depth=2,random_state=0)
rf1.fit(Train_X_Tfidf,Train_Y)
predictions_rf1 = rf1.predict(Test_X_Tfidf)

print("Random Forest Accuracy Score -> ",accuracy_score(predictions_rf1, Test_Y)*100)


# In[28]:


confusion_matrix(Test_Y, predictions_rf1)


# ####  Decision Tree classifier on count vectorizer data

# In[29]:


import sklearn.tree as tree
dec_tree=tree.DecisionTreeClassifier(max_depth=3,random_state=0)
dec_tree.fit(count_train,Train_Y)
predictions_tree = dec_tree.predict(count_test)

print("Decision tree Accuracy Score -> ",accuracy_score(predictions_tree, Test_Y)*100)


# In[30]:


print(classification_report(Test_Y, predictions_tree))


# In[31]:


confusion_matrix(Test_Y, predictions_tree)


# ####  Decision Tree classifier on TFIDF vectorizer data

# In[50]:


dec_tree1=tree.DecisionTreeClassifier(max_depth=3,random_state=0)
dec_tree1.fit(Train_X_Tfidf,Train_Y)
predictions_tree1 = dec_tree1.predict(Test_X_Tfidf)

print("Decision tree Accuracy Score -> ",accuracy_score(predictions_tree1, Test_Y)*100)


# In[55]:


print(classification_report(Test_Y, predictions_tree1))


# In[56]:


confusion_matrix(Test_Y, predictions_tree1)


# In[ ]:




