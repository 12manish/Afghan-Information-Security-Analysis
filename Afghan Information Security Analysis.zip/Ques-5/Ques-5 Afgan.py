#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt                  # Importing required libraries
get_ipython().run_line_magic('matplotlib', 'inline')
import os
import sklearn
import warnings
warnings.filterwarnings("ignore")


# #### Importing dataset

# In[2]:


os.chdir("C:/Users/ABC/Desktop/Afgan Forum paper in R/afghanForum")
data=pd.read_csv("afghanForum.csv",error_bad_lines=False)
data.head()


# In[3]:


dat=data[["MessageID","Message"]]
dat.shape


# #### Sentiment Analysis

# In[4]:


from textblob import TextBlob
import re
import textblob


# In[5]:


def clean_text(text): 
        ''' 
        Utility function to clean text by removing links,
        special characters using simple regex statements. 
        '''
        return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)", " ", text).split()) 

def get_text_sentiment(text):
    ''' 
    Utility function to classify sentiment of passed
    text using textblob's sentiment method 
    '''
    # create TextBlob object of passed text 
    analysis = TextBlob(clean_text(text)) 
    # set sentiment 
    if analysis.sentiment.polarity > 0: 
        return 'positive'
    elif analysis.sentiment.polarity == 0: 
        return 'neutral'
    else: 
        return 'negative'   


# In[6]:


sentiment = []
for message in dat['Message']:
    sentiment.append(get_text_sentiment(message))
    
dat["Sentiment"] = sentiment
dat.head()


# In[7]:


dat['Sentiment_Score'] = dat.Sentiment.map({'positive':1, 'negative':-1,'neutral':0})
dat.head()


# #### Converting text in message column to lower case

# In[8]:


dat['Message'] = [entry.lower() for entry in dat['Message']]
dat.head()


# #### Removing Punctuation and word-tokenization

# In[9]:


from nltk.tokenize import RegexpTokenizer
tokenizer = RegexpTokenizer(r'\w+')
dat['Message']= [tokenizer.tokenize(entry) for entry in dat['Message']]


# In[10]:


dat['Message']=[" ".join(content) for content in dat['Message'].values]


# #### Removing Stop Words

# In[11]:


from nltk.corpus import stopwords
stop = stopwords.words('english')
dat['Message']=dat['Message'].apply(lambda x: " ".join(x for x in x.split() if x not in stop))
dat.head()


# #### Modelling Process

# In[12]:


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn import model_selection, naive_bayes, svm
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report


# In[13]:


Y=dat["Sentiment_Score"]


# #### SPlitting Data into 70:30

# In[14]:


Train_X, Test_X, Train_Y, Test_Y = model_selection.train_test_split(dat['Message'],Y,test_size=0.3)
print(Train_X.shape,Test_X.shape,Train_Y.shape,Test_Y.shape)


# #### TFIDF Vectorizer

# In[15]:


Tfidf_vect = TfidfVectorizer(stop_words='english')
Train_X_Tfidf = Tfidf_vect.fit_transform(Train_X)
Test_X_Tfidf = Tfidf_vect.transform(Test_X)


# #### GBM CLassifier on train data

# In[17]:


from sklearn.ensemble import GradientBoostingClassifier
gbm1 = GradientBoostingClassifier(random_state=10)
gbm1.fit(Train_X_Tfidf,Train_Y)
gbm1.score(Train_X_Tfidf,Train_Y)


# #### Evaluation Of performance Metrices

# In[20]:


prediction_gbm1 = gbm1.predict(Test_X_Tfidf)

print("Confusion Matrix:")
print(confusion_matrix(Test_Y, prediction_gbm1))


# In[21]:


print("Classification Report")
print(classification_report(Test_Y, prediction_gbm1))


# #### C 5.0  Classifier on train data

# In[42]:


from sklearn import tree
dec_tree1=tree.DecisionTreeClassifier(max_depth=5,random_state=42,criterion="entropy")
dec_tree1.fit(Train_X_Tfidf,Train_Y)
predictions_tree1= dec_tree1.predict(Test_X_Tfidf)

print("Decision tree Accuracy Score -> ",accuracy_score(predictions_tree1, Test_Y)*100)


# #### Evaluation Of performance Metrices

# In[43]:


print(classification_report(Test_Y, predictions_tree1))


# In[44]:


confusion_matrix(Test_Y, predictions_tree1)


# #### Bagging CLassifier on train data

# In[23]:


from sklearn.ensemble import BaggingClassifier
from sklearn.tree import DecisionTreeClassifier
Bag=BaggingClassifier(oob_score=True,n_jobs=-1,n_estimators=20,random_state=400,
                      base_estimator=DecisionTreeClassifier())
Bag.fit(Train_X_Tfidf,Train_Y)
Bag.score(Train_X_Tfidf,Train_Y)


# #### Evaluation Of performance Metrices

# In[24]:


prediction_bag = Bag.predict(Test_X_Tfidf)

print("Confusion Matrix:")
print(confusion_matrix(Test_Y, prediction_bag))


# In[26]:


accuracy_score(Test_Y, prediction_bag)


# In[25]:


print("Classification Report")
print(classification_report(Test_Y, prediction_bag))


# #### Random Forest Classifier on train data

# In[28]:


from sklearn.ensemble import RandomForestClassifier
rf= RandomForestClassifier(n_estimators=100, max_depth=2,random_state=0)
rf.fit(Train_X_Tfidf,Train_Y)
predictions_rf = rf.predict(Test_X_Tfidf)

print("Random Forest Accuracy Score -> ",accuracy_score(predictions_rf, Test_Y)*100)


# #### Evaluation Of performance Metrices

# In[29]:


confusion_matrix(Test_Y, predictions_rf)


# In[30]:


print("Classification Report")
print(classification_report(Test_Y, predictions_rf))


# #### Decision Tree Classifier CLassifier on train data

# In[32]:


from sklearn import tree
dec_tree=tree.DecisionTreeClassifier(max_depth=3,random_state=0)
dec_tree.fit(Train_X_Tfidf,Train_Y)
predictions_tree= dec_tree.predict(Test_X_Tfidf)

print("Decision tree Accuracy Score -> ",accuracy_score(predictions_tree, Test_Y)*100)


# #### Evaluation Of performance Metrices

# In[33]:


print(classification_report(Test_Y, predictions_tree))


# In[34]:


confusion_matrix(Test_Y, predictions_tree)


# #### Logistic Regression on train data

# In[36]:


from sklearn.linear_model import LogisticRegression
log=LogisticRegression(random_state=0)
log.fit(Train_X_Tfidf,Train_Y)
predictions_log= log.predict(Test_X_Tfidf)

print("Logistic Regression Accuracy Score -> ",accuracy_score(predictions_log, Test_Y)*100)


# #### Evaluation Of performance Metrices

# In[37]:


print(classification_report(Test_Y, predictions_log))


# In[38]:


confusion_matrix(Test_Y, predictions_log)


# #### SVM  on train data

# In[45]:


SVM= svm.SVC(C=1.0, kernel='linear', degree=3, gamma='auto')
SVM.fit(Train_X_Tfidf,Train_Y)
predictions_SVM= SVM.predict(Test_X_Tfidf)

print("SVM Accuracy Score -> ",accuracy_score(predictions_SVM, Test_Y)*100)


# In[47]:


print(classification_report(Test_Y, predictions_SVM))


# In[48]:


confusion_matrix(Test_Y, predictions_SVM)


# In[ ]:




