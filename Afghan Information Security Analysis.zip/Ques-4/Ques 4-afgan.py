#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt                  # Importing required libraries
get_ipython().run_line_magic('matplotlib', 'inline')
import os
import sklearn
import warnings
warnings.filterwarnings("ignore")


# #### Importing data

# In[4]:


os.chdir("C:/Users/ABC/Desktop/Afgan Forum paper in R/afghanForum")
data=pd.read_csv("afghanForum.csv",error_bad_lines=False)
data.head()


# In[5]:


dat=data[["MessageID","Message"]]
dat.shape


# #### Sentiment Analysis

# In[6]:


from textblob import TextBlob
import re
import textblob


# In[7]:


def clean_text(text): 
        ''' 
        Utility function to clean text by removing links,
        special characters using simple regex statements. 
        '''
        return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)", " ", text).split()) 

def get_text_sentiment(text):
    ''' 
    Utility function to classify sentiment of passed
    text using textblob's sentiment method 
    '''
    # create TextBlob object of passed text 
    analysis = TextBlob(clean_text(text)) 
    # set sentiment 
    if analysis.sentiment.polarity > 0: 
        return 'positive'
    elif analysis.sentiment.polarity == 0: 
        return 'neutral'
    else: 
        return 'negative'    


# In[8]:


sentiment = []
for message in dat['Message']:
    sentiment.append(get_text_sentiment(message))
    
dat["Sentiment"] = sentiment
dat.head()


# In[9]:


dat['Sentiment_Score'] = dat.Sentiment.map({'positive':1, 'negative':-1,'neutral':0})
dat.head()


# #### Data Cleaning

# #### Converting to lower case

# In[10]:


dat['Message'] = [entry.lower() for entry in dat['Message']]
dat.head()


# #### Removing punctuation and word tokenization

# In[11]:


from nltk.tokenize import RegexpTokenizer
tokenizer = RegexpTokenizer(r'\w+')
dat['Message']= [tokenizer.tokenize(entry) for entry in dat['Message']]


# In[12]:


dat['Message']=[" ".join(content) for content in dat['Message'].values]


# #### Removing Stop words

# In[13]:


from nltk.corpus import stopwords
stop = stopwords.words('english')
dat['Message']=dat['Message'].apply(lambda x: " ".join(x for x in x.split() if x not in stop))
dat.head()


# #### Model Processing

# In[14]:


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn import model_selection, naive_bayes, svm
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report


# In[15]:


Y=dat["Sentiment_Score"]


# #### Spliting Data in train and test data in 70:30

# In[16]:


Train_X, Test_X, Train_Y, Test_Y = model_selection.train_test_split(dat['Message'],Y,test_size=0.3)
print(Train_X.shape,Test_X.shape,Train_Y.shape,Test_Y.shape)


# #### TFIDF vectorization

# In[17]:


Tfidf_vect = TfidfVectorizer(stop_words='english')
Train_X_Tfidf = Tfidf_vect.fit_transform(Train_X)
Test_X_Tfidf = Tfidf_vect.transform(Test_X)


# #### Count Vectorizer

# In[18]:


from sklearn.feature_extraction.text import CountVectorizer
count_vectorizer = CountVectorizer(stop_words='english')

# Fit and transform the training data 
count_train = count_vectorizer.fit_transform(Train_X) 

# Transform the test set 
count_test = count_vectorizer.transform(Test_X)


# In[19]:


print(Train_X_Tfidf.shape,Test_X_Tfidf.shape,count_train.shape,count_test.shape)


# #### Random Forest  ALgorithm On train  for COunt vectorizer

# In[18]:


from sklearn.ensemble import RandomForestClassifier
rf= RandomForestClassifier(n_estimators=100, max_depth=2,random_state=0)
rf.fit(count_train,Train_Y)
predictions_rf = rf.predict(count_test)

print("Random Forest Accuracy Score -> ",accuracy_score(predictions_rf, Test_Y)*100)


# In[19]:


confusion_matrix(Test_Y, predictions_rf)


# #### Random Forest  ALgorithm On train  for TFIDF vectorizer

# In[20]:


rf1= RandomForestClassifier(n_estimators=100, max_depth=2,random_state=0)
rf1.fit(Train_X_Tfidf,Train_Y)
predictions_rf1 = rf1.predict(Test_X_Tfidf)

print("Random Forest Accuracy Score -> ",accuracy_score(predictions_rf1, Test_Y)*100)


# In[21]:


confusion_matrix(Test_Y, predictions_rf1)


# #### Logistic Regression ALgorithm On train  for Count vectorizer

# In[22]:


from sklearn.linear_model import LogisticRegression
log=LogisticRegression(random_state=0)
log.fit(count_train,Train_Y)
predictions_log= log.predict(count_test)

print("Logistic Regression Accuracy Score -> ",accuracy_score(predictions_log, Test_Y)*100)


# In[23]:


print(classification_report(Test_Y, predictions_log))


# In[24]:


confusion_matrix(Test_Y, predictions_log)


# #### Logistic Regression ALgorithm On train  for TFIDF vectorizer

# In[25]:


log1=LogisticRegression(random_state=0)
log1.fit(Train_X_Tfidf,Train_Y)
predictions_log1= log1.predict(Test_X_Tfidf)

print("Logistic Regression Accuracy Score -> ",accuracy_score(predictions_log1, Test_Y)*100)


# In[26]:


print(classification_report(Test_Y, predictions_log1))


# In[27]:


confusion_matrix(Test_Y, predictions_log1)


# #### KNN ALgorithm On train  for Count vectorizer

# In[28]:


from sklearn.neighbors import KNeighborsClassifier


# In[ ]:


knn = KNeighborsClassifier(n_neighbors=4)
knn.fit(count_train,Train_Y)
knn.score(count_train,Train_Y)


# #### KNN ALgorithm On train  for TFIDF vectorizer

# In[ ]:


knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(Train_X_Tfidf,Train_Y)
knn.score(Train_X_Tfidf,Train_Y)


# #### GBM ALgorithm On train  for Count vectorizer

# In[20]:


from sklearn.ensemble import GradientBoostingClassifier


# In[21]:


gbm = GradientBoostingClassifier(random_state=10)
gbm.fit(count_train,Train_Y)
gbm.score(count_train,Train_Y)


# In[22]:


prediction_gbm = gbm.predict(count_test)

print("Confusion Matrix:")
print(confusion_matrix(Test_Y, prediction_gbm))


# In[23]:


print("Classification Report")
print(classification_report(Test_Y, prediction_gbm))


# #### GBM ALgorithm On train  for TFIDF vectorizer

# In[24]:


gbm1 = GradientBoostingClassifier(random_state=10)
gbm1.fit(Train_X_Tfidf,Train_Y)
gbm1.score(Train_X_Tfidf,Train_Y)


# In[25]:


prediction_gbm1 = gbm1.predict(Test_X_Tfidf)

print("Confusion Matrix:")
print(confusion_matrix(Test_Y, prediction_gbm1))


# In[26]:


print("Classification Report")
print(classification_report(Test_Y, prediction_gbm1))

